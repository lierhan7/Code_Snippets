import yaml
from pathlib import Path
import argparse
from src.data_processing.fastq_processor import FastqProcessor
from src.analysis.alignment import Aligner
from src.utils.logger import setup_logger

def main():
    parser = argparse.ArgumentParser(description='Run complete bioinformatics pipeline')
    parser.add_argument('--config', type=str, required=True, help='Path to config file')
    args = parser.parse_args()
    
    # 设置日志
    logger = setup_logger("main", Path("pipeline.log"))
    
    # 读取配置
    with open(args.config) as f:
        config = yaml.safe_load(f)
    
    # 初始化处理器
    fastq_processor = FastqProcessor(config)
    aligner = Aligner(config)
    
    # 获取样本列表
    input_dir = Path(config['paths']['input_dir'])
    samples = [f.stem for f in input_dir.glob("*.fastq")]
    
    # 处理每个样本
    for sample_id in samples:
        try:
            # FASTQ处理
            cleaned_fastq = fastq_processor.process_sample(sample_id)
            
            # 序列比对
            output_bam = Path(config['paths']['output_dir']) / f"{sample_id}.bam"
            aligner.align_reads(cleaned_fastq, output_bam)
            
            logger.info(f"Successfully processed sample {sample_id}")
            
        except Exception as e:
            logger.error(f"Failed to process sample {sample_id}: {e}")
            continue

if __name__ == "__main__":
    main()