from typing import List, Dict, Any
import networkx as nx
from pathlib import Path
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

# 定义 logger
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class Task:
    """工作流任务"""
    
    def __init__(self, name: str, func: callable, **kwargs):
        self.name = name
        self.func = func
        self.kwargs = kwargs
        self.status = "pending"
        self.result = None
        self.error = None
    
    def run(self):
        """执行任务"""
        try:
            self.result = self.func(**self.kwargs)
            self.status = "completed"
        except Exception as e:
            self.error = str(e)
            self.status = "failed"
            raise

class Workflow:
    """工作流管理器"""
    
    def __init__(self):
        self.graph = nx.DiGraph()
        self.tasks: Dict[str, Task] = {}
    
    def add_task(self, task: Task, dependencies: List[str] = None):
        """添加任务到工作流"""
        self.tasks[task.name] = task
        self.graph.add_node(task.name)
        if dependencies:
            for dep in dependencies:
                if dep not in self.tasks:
                    raise ValueError(f"Dependency {dep} not found")
                self.graph.add_edge(dep, task.name)
    
    def validate(self):
        """验证工作流"""
        if not nx.is_directed_acyclic_graph(self.graph):
            raise ValueError("Workflow contains cycles")
    
    def get_ready_tasks(self) -> List[str]:
        """获取可以执行的任务"""
        ready = []
        for task_name in self.graph.nodes:
            if self.tasks[task_name].status == "pending":
                deps = list(self.graph.predecessors(task_name))
                if all(self.tasks[dep].status == "completed" for dep in deps):
                    ready.append(task_name)
        return ready
    
    def run_parallel(self, max_workers: int = 4):
        """并行执行工作流"""
        self.validate()
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            while True:
                ready_tasks = self.get_ready_tasks()
                if not ready_tasks:
                    break
                
                futures = []
                for task_name in ready_tasks:
                    task = self.tasks[task_name]
                    future = executor.submit(task.run)
                    futures.append((task_name, future))
                
                for task_name, future in futures:
                    try:
                        future.result()
                    except Exception as e:
                        logger.error(f"Task {task_name} failed: {e}")
    
    def save_state(self, path: Path):
        """保存工作流状态"""
        state = {
            name: {
                "status": task.status,
                "error": task.error
            } for name, task in self.tasks.items()
        }
        with open(path, 'w') as f:
            json.dump(state, f, indent=2)