from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Optional
import yaml
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class BasePipeline(ABC):
    """流程基类"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or self.get_default_config()
        self.validate_config()
        
    @staticmethod
    @abstractmethod
    def get_default_config() -> Dict:
        """获取默认配置"""
        pass
    
    @abstractmethod
    def validate_config(self):
        """验证配置"""
        pass
    
    @abstractmethod
    def run(self, *args, **kwargs):
        """运行流程"""
        pass
    
    def save_config(self, path: Path):
        """保存当前配置"""
        with open(path, 'w') as f:
            yaml.dump(self.config, f)
    
    @classmethod
    def load_config(cls, path: Path) -> Dict:
        """加载配置文件"""
        with open(path) as f:
            return yaml.safe_load(f)