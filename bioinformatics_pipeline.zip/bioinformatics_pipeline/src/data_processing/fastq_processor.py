from pathlib import Path
from typing import List, Dict
import subprocess
import argparse
from ..utils.logger import setup_logger
import yaml

logger = setup_logger(__name__)

class FastqProcessor:
    """FASTQ文件处理类"""
    
    def __init__(self, config: Dict = None):
        if config is None:
            config = self.get_default_config()
        self.config = config
        self.input_dir = Path(config['paths']['input_dir'])
        self.output_dir = Path(config['paths']['output_dir'])
        self.min_quality = config['parameters']['min_quality']
        
    @staticmethod
    def get_default_config() -> Dict:
        """获取默认配置"""
        return {
            'paths': {
                'input_dir': './input',
                'output_dir': './output'
            },
            'parameters': {
                'min_quality': 20
            }
        }
    
    def process_sample(self, sample_id: str) -> Path:
        """处理单个样本的FASTQ文件"""
        logger.info(f"Processing sample: {sample_id}")
        
        input_file = self.input_dir / f"{sample_id}.fastq"
        output_file = self.output_dir / f"{sample_id}.cleaned.fastq"
        
        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        # 质控和过滤
        self._run_quality_control(input_file, output_file)
        
        return output_file
    
    def _run_quality_control(self, input_file: Path, output_file: Path):
        """运行质量控制"""
        cmd = [
            "fastp",
            "-i", str(input_file),
            "-o", str(output_file),
            "-q", str(self.min_quality),
            "--json", str(output_file.with_suffix(".json")),
            "--html", str(output_file.with_suffix(".html"))
        ]
        
        try:
            subprocess.run(cmd, check=True)
            logger.info(f"Quality control completed for {input_file}")
        except subprocess.CalledProcessError as e:
            logger.error(f"Quality control failed for {input_file}: {e}")
            raise

def main():
    """命令行入口点"""
    parser = argparse.ArgumentParser(description='Process FASTQ files')
    parser.add_argument('--config', type=str, help='Path to config file')
    parser.add_argument('--sample', type=str, help='Sample ID to process')
    parser.add_argument('--input-dir', type=str, help='Input directory')
    parser.add_argument('--output-dir', type=str, help='Output directory')
    parser.add_argument('--min-quality', type=int, help='Minimum quality score')
    
    args = parser.parse_args()
    
    # 加载配置
    if args.config:
        with open(args.config) as f:
            config = yaml.safe_load(f)
    else:
        config = FastqProcessor.get_default_config()
    
    # 命令行参数覆盖配置文件
    if args.input_dir:
        config['paths']['input_dir'] = args.input_dir
    if args.output_dir:
        config['paths']['output_dir'] = args.output_dir
    if args.min_quality:
        config['parameters']['min_quality'] = args.min_quality
    
    # 初始化处理器
    processor = FastqProcessor(config)
    
    if args.sample:
        # 处理单个样本
        processor.process_sample(args.sample)
    else:
        # 处理所有样本
        input_dir = Path(config['paths']['input_dir'])
        samples = [f.stem for f in input_dir.glob("*.fastq")]
        for sample_id in samples:
            try:
                processor.process_sample(sample_id)
            except Exception as e:
                logger.error(f"Failed to process sample {sample_id}: {e}")
                continue

if __name__ == "__main__":
    main()