import psutil
import threading
from typing import Dict

class ResourceMonitor:
    """资源监控器"""
    
    def __init__(self, interval: float = 1.0):
        self.interval = interval
        self._stop_event = threading.Event()
        self._stats: Dict[str, list] = {
            'cpu_percent': [],
            'memory_percent': [],
            'disk_io': []
        }
    
    def start(self):
        """开始监控"""
        threading.Thread(target=self._monitor, daemon=True).start()
    
    def stop(self):
        """停止监控"""
        self._stop_event.set()
    
    def _monitor(self):
        """监控循环"""
        while not self._stop_event.is_set():
            self._stats['cpu_percent'].append(psutil.cpu_percent())
            self._stats['memory_percent'].append(psutil.virtual_memory().percent)
            self._stats['disk_io'].append(psutil.disk_io_counters())
            time.sleep(self.interval)
    
    def get_stats(self) -> Dict[str, list]:
        """获取统计数据"""
        return self._stats
    
    def get_summary(self) -> Dict[str, float]:
        """获取统计摘要"""
        if not self._stats['cpu_percent']:
            return {}
        
        return {
            'cpu_avg': sum(self._stats['cpu_percent']) / len(self._stats['cpu_percent']),
            'memory_avg': sum(self._stats['memory_percent']) / len(self._stats['memory_percent']),
            'cpu_max': max(self._stats['cpu_percent']),
            'memory_max': max(self._stats['memory_percent'])
        }
