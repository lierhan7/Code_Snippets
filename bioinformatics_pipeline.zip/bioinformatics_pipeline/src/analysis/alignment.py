from pathlib import Path
from typing import Dict
import subprocess
import argparse
import yaml
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class Aligner:
    """序列比对类"""
    
    def __init__(self, config: Dict = None):
        if config is None:
            config = self.get_default_config()
        self.config = config
        self.reference = Path(config['paths']['reference_genome'])
        self.threads = config['parameters']['threads']
    
    @staticmethod
    def get_default_config() -> Dict:
        """获取默认配置"""
        return {
            'paths': {
                'reference_genome': './reference/genome.fa'
            },
            'parameters': {
                'threads': 4
            }
        }
    
    def align_reads(self, input_file: Path, output_file: Path):
        """执行序列比对"""
        logger.info(f"Starting alignment for {input_file}")
        
        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        cmd = [
            "bwa", "mem",
            "-t", str(self.threads),
            str(self.reference),
            str(input_file),
            "|",
            "samtools", "sort",
            "-@", str(self.threads),
            "-o", str(output_file)
        ]
        
        try:
            subprocess.run(" ".join(cmd), shell=True, check=True)
            logger.info(f"Alignment completed for {input_file}")
            
            # 创建索引
            subprocess.run([
                "samtools", "index",
                str(output_file)
            ], check=True)
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Alignment failed for {input_file}: {e}")
            raise

def main():
    """命令行入口点"""
    parser = argparse.ArgumentParser(description='Align sequences to reference genome')
    parser.add_argument('--config', type=str, help='Path to config file')
    parser.add_argument('--input', type=str, required=True, help='Input FASTQ file')
    parser.add_argument('--output', type=str, required=True, help='Output BAM file')
    parser.add_argument('--reference', type=str, help='Reference genome path')
    parser.add_argument('--threads', type=int, help='Number of threads')
    
    args = parser.parse_args()
    
    # 加载配置
    if args.config:
        with open(args.config) as f:
            config = yaml.safe_load(f)
    else:
        config = Aligner.get_default_config()
    
    # 命令行参数覆盖配置文件
    if args.reference:
        config['paths']['reference_genome'] = args.reference
    if args.threads:
        config['parameters']['threads'] = args.threads
    
    # 初始化比对器并执行比对
    aligner = Aligner(config)
    aligner.align_reads(Path(args.input), Path(args.output))

if __name__ == "__main__":
    main()