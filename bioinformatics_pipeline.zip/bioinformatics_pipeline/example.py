# Example usage of the optimized framework
def example_usage():
    # 创建工作流
    workflow = Workflow()
    
    # 定义任务
    @retry(max_attempts=3)
    @log_execution()
    def process_fastq(sample_id: str):
        processor = FastqProcessor()
        return processor.process_sample(sample_id)
    
    @retry(max_attempts=3)
    @log_execution()
    def align_reads(input_file: Path, output_file: Path):
        aligner = Aligner()
        return aligner.align_reads(input_file, output_file)
    
    # 添加任务到工作流
    workflow.add_task(Task(
        name="process_fastq",
        func=process_fastq,
        sample_id="sample1"
    ))
    
    workflow.add_task(Task(
        name="align_reads",
        func=align_reads,
        input_file=Path("sample1.cleaned.fastq"),
        output_file=Path("sample1.bam")
    ), dependencies=["process_fastq"])
    
    # 启动资源监控
    monitor = ResourceMonitor()
    monitor.start()
    
    # 执行工作流
    workflow.run_parallel(max_workers=4)
    
    # 停止监控并获取统计信息
    monitor.stop()
    stats = monitor.get_summary()
    print(f"Resource usage statistics: {stats}")
    
    # 保存工作流状态
    workflow.save_state(Path("workflow_state.json"))

if __name__ == "__main__":
    example_usage()