
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

def detect_peak_boundaries(rt, intensity, liftoff=0.0, touchdown=0.005):
    # 平滑数据
    smoothed_intensity = savgol_filter(intensity, window_length=7, polyorder=2)

    # 计算一阶和二阶导数
    first_derivative = np.gradient(smoothed_intensity)
    second_derivative = np.gradient(first_derivative)

    # 找到二阶导数的零交叉点（拐点）
    inflection_points = np.where(np.diff(np.sign(second_derivative)))[0]

    # 在拐点之间找到局部最小值（峰顶）
    peak_indices = []
    for i in range(len(inflection_points) - 1):
        start, end = inflection_points[i], inflection_points[i+1]
        local_min = np.argmin(smoothed_intensity[start:end]) + start
        if second_derivative[local_min] < 0:  # 确保是负的局部最小值
            peak_indices.append(local_min)

    # 对每个检测到的峰应用修改后的ApexTrack算法
    peak_boundaries = []
    for peak_index in peak_indices:
        # 找到峰两侧的拐点
        left_inflection = max([i for i in inflection_points if i < peak_index])
        right_inflection = min([i for i in inflection_points if i > peak_index])

        # 初始基线
        left_bound, right_bound = left_inflection, right_inflection
        initial_left_slope = (smoothed_intensity[peak_index] - smoothed_intensity[left_bound]) / (peak_index - left_bound)
        initial_right_slope = (smoothed_intensity[right_bound] - smoothed_intensity[peak_index]) / (right_bound - peak_index)

        # 向左扩展基线
        while left_bound > 0:
            new_left_bound = left_bound - 1
            new_left_slope = (smoothed_intensity[peak_index] - smoothed_intensity[new_left_bound]) / (peak_index - new_left_bound)
            if abs(new_left_slope - initial_left_slope) / abs(initial_left_slope) <= liftoff:
                left_bound = new_left_bound
            else:
                break

        # 向右扩展基线
        while right_bound < len(smoothed_intensity) - 1:
            new_right_bound = right_bound + 1
            new_right_slope = (smoothed_intensity[new_right_bound] - smoothed_intensity[peak_index]) / (new_right_bound - peak_index)
            if abs(new_right_slope - initial_right_slope) / abs(initial_right_slope) <= touchdown:
                right_bound = new_right_bound
            else:
                break

        peak_boundaries.append((rt[left_bound], rt[right_bound]))

    return peak_boundaries



if __name__ == "__main__":

    feature_matrix_file = "rt15s/191017USXP001_PN.feature_matrix.csv"
    feature_matrix_df = pd.read_csv(feature_matrix_file, float_precision="high")

    feature_id = 14143358854026598834

    rt = feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,2] 
    mz = feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,3]

    rts = [ float(i) for i in feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,14].split(",") ]
    intys = [ float(i) for i in feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,15].split(",") ]

    data = {
        'rt': rts,
        'intensity': intys,
        'smoothed_intensity': intys,
        'label': ['trace1'] * len(rts)
    }

    mt = pd.DataFrame(data)

    # 在主程序中，替换原来的 start_rt 和 end_rt 赋值
    peak_boundaries = detect_peak_boundaries(mt['rt'].values, mt['intensity'].values)

    if len(peak_boundaries) == 0:
        print("No peaks detected.")
        exit()
    elif len(peak_boundaries) == 1:
        start_rt, end_rt = peak_boundaries[0]
    else:
        # 从所有检测到的峰中选择 apex rt 与 rt 最接近的峰
        min_diff = np.inf
        min_diff_idx = 0
        for i, (peak_start, peak_end) in enumerate(peak_boundaries):
            # 将 RT 值转换为索引
            start_idx = mt['rt'].searchsorted(peak_start)
            end_idx = mt['rt'].searchsorted(peak_end)

            # 确保索引范围有效
            if start_idx == end_idx:
                end_idx = min(end_idx + 1, len(mt) - 1)

            if start_idx < end_idx:
                peak_slice = mt['intensity'].iloc[start_idx:end_idx]
                if not peak_slice.empty:
                    peak_apex_idx = peak_slice.idxmax()
                    peak_apex = mt['rt'].iloc[peak_apex_idx]
                    diff = abs(rt - peak_apex)
                    if diff < min_diff:
                        min_diff = diff
                        min_diff_idx = i

        if min_diff_idx < len(peak_boundaries):
            start_rt, end_rt = peak_boundaries[min_diff_idx]
        else:
            print("No valid peaks found.")
            exit()

    # 更新图形绘制代码
    plt.axvline(x=start_rt, color='g', linestyle='--', label='Peak start')
    plt.axvline(x=end_rt, color='g', linestyle='--', label='Peak end')

    plt.savefig(f"{feature_id}.png", bbox_inches='tight')