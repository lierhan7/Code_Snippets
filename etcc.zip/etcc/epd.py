import numpy as np
import scipy.signal
import math
from typing import List

class ElutionPeakDetection:
    def __init__(self):
        self.chrom_fwhm = 5.0
        self.chrom_peak_snr = 3.0
        self.min_fwhm = 1.0
        self.max_fwhm = 60.0
        self.pw_filtering = "fixed"
        self.mt_snr_filtering = False

    def compute_mass_trace_noise(self, intensities: List[float], smoothed_intensities: List[float]) -> float:
        squared_sum = sum((i - si) ** 2 for i, si in zip(intensities, smoothed_intensities))
        rmse = math.sqrt(squared_sum / len(smoothed_intensities)) if smoothed_intensities else 0.0
        return rmse

    def compute_mass_trace_snr(self, intensities: List[float], smoothed_intensities: List[float], peak_area: float, trace_length: float) -> float:
        noise_area = self.compute_mass_trace_noise(intensities, smoothed_intensities) * trace_length
        snr = peak_area / noise_area if noise_area > 0 else 0.0
        return snr

    def compute_apex_snr(self, intensities: List[float], smoothed_intensities: List[float], max_intensity: float) -> float:
        noise_level = self.compute_mass_trace_noise(intensities, smoothed_intensities)
        snr = max_intensity / noise_level if noise_level > 0.0 else 0.0
        return snr

    def find_local_extrema(self, smoothed_intensities: List[float], num_neighboring_peaks: int) -> (List[int], List[int]):
        mt_length = len(smoothed_intensities)

        chrom_maxes = []
        chrom_mins = []

        intensity_indices = sorted(range(mt_length), key=lambda i: smoothed_intensities[i])

        used_idx = [False] * mt_length

        for ref_idx in intensity_indices:
            ref_int = smoothed_intensities[ref_idx]
            if not used_idx[ref_idx] and ref_int > 0.0:
                real_max = True
                start_idx = max(0, ref_idx - num_neighboring_peaks)
                end_idx = min(mt_length, ref_idx + num_neighboring_peaks)

                for j in range(start_idx, end_idx):
                    if j == ref_idx:
                        continue
                    if used_idx[j]:
                        if smoothed_intensities[j] > ref_int:
                            real_max = False
                            break
                    elif smoothed_intensities[j] > ref_int:
                        real_max = False
                        break

                if real_max:
                    chrom_maxes.append(ref_idx)
                    for j in range(start_idx, end_idx):
                        used_idx[j] = True

        chrom_maxes.sort()

        if len(chrom_maxes) > 1:
            left_idx, right_idx = 0, 1
            while left_idx < right_idx and right_idx < len(chrom_maxes):
                left_bound = chrom_maxes[left_idx] + 1
                right_bound = chrom_maxes[right_idx] - 1
                while left_bound + 1 < right_bound:
                    mid_dist = (right_bound - left_bound) / 2.0
                    mid_element_idx = left_bound + int(math.floor(mid_dist))
                    mid_element_int = smoothed_intensities[mid_element_idx]

                    if mid_element_int <= smoothed_intensities[mid_element_idx + 1]:
                        right_bound = mid_element_idx
                    else:
                        left_bound = mid_element_idx

                min_rt = left_bound if smoothed_intensities[left_bound] < smoothed_intensities[right_bound] else right_bound
                chrom_mins.append(min_rt)
                left_idx = right_idx
                right_idx += 1

        return chrom_maxes, chrom_mins

    def smooth_data(self, intensities: List[float], win_size: int) -> List[float]:
        smoothed_intensities = scipy.signal.savgol_filter(intensities, win_size, 2)
        return smoothed_intensities

# Example usage
elution_peak_detection = ElutionPeakDetection()
intensities = [1, 2, 3, 4, 5, 4, 3, 2, 1]  # Example data
win_size = 5

# Smooth data
smoothed_intensities = elution_peak_detection.smooth_data(intensities, win_size)
# Find local extrema
chrom_maxes, chrom_mins = elution_peak_detection.find_local_extrema(smoothed_intensities, win_size // 2)

