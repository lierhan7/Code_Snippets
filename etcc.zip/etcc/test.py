import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from multiprocessing import Pool

class ElutionPeakDetection:
    def __init__(self):
        self.chrom_fwhm = 5.0
        self.chrom_peak_snr = 3.0
        self.min_fwhm = 1.0
        self.max_fwhm = 60.0
        self.width_filtering = "fixed"
        self.masstrace_snr_filtering = False

    def compute_mass_trace_noise(self, tr):
        # Compute RMSE
        squared_sum = np.sum((tr['intensity'] - tr['smoothed_intensity']) ** 2)
        rmse = np.sqrt(squared_sum / len(tr))
        return rmse

    def compute_mass_trace_snr(self, tr):
        noise_area = self.compute_mass_trace_noise(tr) * len(tr)
        signal_area = np.trapz(tr['smoothed_intensity'], tr['rt'])
        snr = signal_area / noise_area
        return snr

    def compute_apex_snr(self, tr):
        noise_level = self.compute_mass_trace_noise(tr)
        smoothed_apex_int = np.max(tr['smoothed_intensity'])
        snr = smoothed_apex_int / noise_level if noise_level > 0 else 0
        return snr

    def find_local_extrema(self, tr, num_neighboring_peaks):
        smoothed_ints_vec = tr['smoothed_intensity'].values
        mt_length = len(smoothed_ints_vec)

        # Extract RTs and intensities
        rt_values = tr['rt'].values
        intensity_indices = sorted(zip(smoothed_ints_vec, np.arange(mt_length)), reverse=True)

        used_idx = np.zeros(mt_length, dtype=bool)
        chrom_maxes = []
        chrom_mins = []

        # Step 1: Identify maxima
        for ref_int, ref_idx in intensity_indices:
            if not used_idx[ref_idx] and ref_int > 0:
                real_max = True
                start_idx = max(0, ref_idx - num_neighboring_peaks)
                end_idx = min(mt_length, ref_idx + num_neighboring_peaks + 1)

                for j in range(start_idx, end_idx):
                    if j == ref_idx:
                        continue
                    if used_idx[j] and smoothed_ints_vec[j] > ref_int:
                        real_max = False
                        break
                    if smoothed_ints_vec[j] > ref_int:
                        real_max = False
                        break

                if real_max:
                    chrom_maxes.append(ref_idx)
                    used_idx[start_idx:end_idx] = True

        chrom_maxes.sort()

        # Step 2: Identify minima using bisection between two maxima
        if len(chrom_maxes) > 1:
            left_idx, right_idx = 0, 1
            while left_idx < right_idx < len(chrom_maxes):
                left_bound = chrom_maxes[left_idx] + 1
                right_bound = chrom_maxes[right_idx] - 1
                while (left_bound + 1) < right_bound:
                    mid_dist = (right_bound - left_bound) / 2.0
                    mid_element_idx = left_bound + int(np.floor(mid_dist))
                    mid_element_int = smoothed_ints_vec[mid_element_idx]

                    if mid_element_int <= smoothed_ints_vec[mid_element_idx + 1]:
                        right_bound = mid_element_idx
                    else:
                        left_bound = mid_element_idx

                min_rt = left_bound if smoothed_ints_vec[left_bound] < smoothed_ints_vec[right_bound] else right_bound
                min_int = smoothed_ints_vec[min_rt]

                left_max_int = smoothed_ints_vec[chrom_maxes[left_idx]]
                right_max_int = smoothed_ints_vec[chrom_maxes[right_idx]]

                left_rt = rt_values[chrom_maxes[left_idx]]
                mid_rt = rt_values[min_rt]
                right_rt = rt_values[chrom_maxes[right_idx]]

                left_dist = abs(mid_rt - left_rt)
                right_dist = abs(right_rt - mid_rt)
                min_dist = self.min_fwhm / 2.0

                if (left_max_int / min_int >= 2.0 and
                    right_max_int / min_int >= 2.0 and
                    left_dist >= min_dist and
                    right_dist >= min_dist):
                    chrom_mins.append(min_rt)
                    left_idx = right_idx
                    right_idx += 1
                else:
                    if left_max_int > right_max_int:
                        right_idx += 1
                    else:
                        left_idx = right_idx
                        right_idx += 1

        return chrom_maxes, chrom_mins

    def detect_peaks(self, mt, single_mtraces):
        single_mtraces.clear()
        self.detect_elution_peaks(mt, single_mtraces)

    def detect_peaks_parallel(self, mt_vec, single_mtraces):
        single_mtraces.clear()
        with Pool() as pool:
            results = pool.map(self.detect_elution_peaks, mt_vec)
            for result in results:
                single_mtraces.extend(result)

    def detect_elution_peaks(self, mt):
        scan_time = np.mean(np.diff(mt['rt']))
        win_size = int(np.ceil(self.chrom_fwhm / scan_time))

        # Step 1: Smooth data
        self.smooth_data(mt, win_size)

        # Step 2: Identify local maxima and minima
        maxes, mins = self.find_local_extrema(mt, win_size // 2)

        # Step 3: Split mass trace according to detected peaks
        if len(maxes) == 1:
            pw_ok = True
            snr_ok = True

            if self.width_filtering == "fixed":
                act_fwhm = self.estimate_fwhm(mt)
                if act_fwhm < self.min_fwhm or act_fwhm > self.max_fwhm:
                    pw_ok = False

            if self.masstrace_snr_filtering:
                if self.compute_apex_snr(mt) < self.chrom_peak_snr:
                    snr_ok = False

            if pw_ok and snr_ok:
                mt['smoothed_max_rt'] = mt['rt'][np.argmax(mt['smoothed_intensity'])]
                if self.width_filtering != "fixed":
                    self.estimate_fwhm(mt)
                return [mt]
        elif not maxes:
            return []
        else:
            sub_traces = []
            last_idx = 0
            mins.append(len(mt) - 1)

            for min_idx in mins:
                sub_trace = mt.iloc[last_idx:min_idx + 1].copy()
                last_idx = min_idx + 1

                pw_ok = True
                snr_ok = True

                if self.width_filtering == "fixed":
                    act_fwhm = self.estimate_fwhm(sub_trace)
                    if act_fwhm < self.min_fwhm or act_fwhm > self.max_fwhm:
                        pw_ok = False

                if self.masstrace_snr_filtering:
                    if self.compute_apex_snr(sub_trace) < self.chrom_peak_snr:
                        snr_ok = False

                if pw_ok and snr_ok:
                    sub_trace['smoothed_max_rt'] = sub_trace['rt'][np.argmax(sub_trace['smoothed_intensity'])]
                    sub_trace['label'] = f"{mt['label'].iloc[0]}.{min_idx + 1}"
                    if self.width_filtering != "fixed":
                        self.estimate_fwhm(sub_trace)
                    sub_traces.append(sub_trace)

            return sub_traces

    def smooth_data(self, mt, win_size):
        mt['smoothed_intensity'] = savgol_filter(mt['intensity'], window_length=win_size, polyorder=2)

    def estimate_fwhm(self, mt):
        # Placeholder for FWHM estimation logic
        return 5.0  # Example value
