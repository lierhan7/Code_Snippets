
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter
from multiprocessing import Pool


def int_entropy_calculator(data_peak_sheak):
    """Internal function to calculate entropy."""
    total_intensity = np.sum(data_peak_sheak[:, 1])
    probabilities = data_peak_sheak[:, 1] / total_intensity
    entropy = -np.sum(probabilities * np.log2(probabilities))
    return entropy

def entropy_calculator(eic_data):
    """
    Calculate the entropy of a peak and the retention time of max intensity.
    
    Parameters:
    eic_data (numpy.ndarray): A 2D array where the first column is retention time and the second column is intensity.
    
    Returns:
    tuple: A tuple containing the retention time of max intensity and the entropy score.
    """
    max_int = np.max(eic_data[:, 1])
    if max_int == 0:
        entropy_score = 100
        max_tr = 'None'
    else:
        max_int_index = np.argmax(eic_data[:, 1])
        max_tr = eic_data[max_int_index, 0]
        data_peak_sheak = np.array([[0, 0]])
        data_added = np.array([[0, 0]])
        nrow_eic_data = eic_data.shape[0]
        num_sheak = 0
        
        if max_int_index != 0 and max_int_index != nrow_eic_data - 1:
            for i in range(1, max_int_index + 1):
                if eic_data[i, 1] - eic_data[i - 1, 1] < 0:
                    num_sheak += 1
                    data_added[0, 0] = i
                    data_added[0, 1] = abs(eic_data[i, 1] - eic_data[i - 1, 1])
                    data_peak_sheak = np.vstack([data_peak_sheak, data_added])
            num_sheak += 1
            data_added[0, 0] = max_int_index
            data_added[0, 1] = np.max(eic_data[:, 1])
            data_peak_sheak = np.vstack([data_peak_sheak, data_added])
            
            for i in range(max_int_index + 1, nrow_eic_data):
                if eic_data[i, 1] - eic_data[i - 1, 1] > 0:
                    num_sheak += 1
                    data_added[0, 0] = i
                    data_added[0, 1] = abs(eic_data[i, 1] - eic_data[i - 1, 1])
                    data_peak_sheak = np.vstack([data_peak_sheak, data_added])
        elif max_int_index == 0:
            for i in range(max_int_index + 1, nrow_eic_data):
                num_sheak += 1
                data_added[0, 0] = max_int_index
                data_added[0, 1] = np.max(eic_data[:, 1])
                data_peak_sheak = np.vstack([data_peak_sheak, data_added])
                if eic_data[i, 1] - eic_data[i - 1, 1] > 0:
                    num_sheak += 1
                    data_added[0, 0] = i
                    data_added[0, 1] = abs(eic_data[i, 1] - eic_data[i - 1, 1])
                    data_peak_sheak = np.vstack([data_peak_sheak, data_added])
        elif max_int_index == nrow_eic_data - 1:
            for i in range(1, max_int_index + 1):
                if eic_data[i, 1] - eic_data[i - 1, 1] < 0:
                    num_sheak += 1
                    data_added[0, 0] = i
                    data_added[0, 1] = abs(eic_data[i, 1] - eic_data[i - 1, 1])
                    data_peak_sheak = np.vstack([data_peak_sheak, data_added])
            num_sheak += 1
            data_added[0, 0] = max_int_index
            data_added[0, 1] = np.max(eic_data[:, 1])
            data_peak_sheak = np.vstack([data_peak_sheak, data_added])
        
        data_peak_sheak = data_peak_sheak[1:]
        entropy_score = int_entropy_calculator(data_peak_sheak)
    
    return max_tr, entropy_score


class ElutionPeakDetection:
    def __init__(self):
        self.chrom_fwhm = 5.0
        self.chrom_peak_snr = 3.0
        self.min_fwhm = 1.0
        self.max_fwhm = 60.0
        self.width_filtering = "fixed"
        self.masstrace_snr_filtering = True

    def compute_mass_trace_noise(self, tr):
        # Compute RMSE
        squared_sum = np.sum((tr['intensity'] - tr['smoothed_intensity']) ** 2)
        rmse = np.sqrt(squared_sum / len(tr))
        return rmse

    def compute_mass_trace_snr(self, tr):
        noise_area = self.compute_mass_trace_noise(tr) * len(tr)
        signal_area = np.trapz(tr['smoothed_intensity'], tr['rt'])
        snr = signal_area / noise_area
        return snr

    def compute_apex_snr(self, tr):
        noise_level = self.compute_mass_trace_noise(tr)
        smoothed_apex_int = np.max(tr['smoothed_intensity'])
        snr = smoothed_apex_int / noise_level if noise_level > 0 else 0
        return snr

    def find_local_extrema(self, tr, num_neighboring_peaks):
        smoothed_ints_vec = tr['smoothed_intensity'].values
        mt_length = len(smoothed_ints_vec)

        # Extract RTs and intensities
        rt_values = tr['rt'].values
        intensity_indices = sorted(zip(smoothed_ints_vec, np.arange(mt_length)), reverse=True)

        used_idx = np.zeros(mt_length, dtype=bool)
        chrom_maxes = []
        chrom_mins = []

        # Step 1: Identify maxima
        for ref_int, ref_idx in intensity_indices:
            if not used_idx[ref_idx] and ref_int > 0:
                real_max = True
                start_idx = max(0, ref_idx - num_neighboring_peaks)
                end_idx = min(mt_length, ref_idx + num_neighboring_peaks + 1)

                for j in range(start_idx, end_idx):
                    if j == ref_idx:
                        continue
                    if used_idx[j] and smoothed_ints_vec[j] > ref_int:
                        real_max = False
                        break
                    if smoothed_ints_vec[j] > ref_int:
                        real_max = False
                        break

                if real_max:
                    chrom_maxes.append(ref_idx)
                    used_idx[start_idx:end_idx] = True

        chrom_maxes.sort()

        # Step 2: Identify minima using bisection between two maxima
        if len(chrom_maxes) > 1:
            left_idx, right_idx = 0, 1
            while left_idx < right_idx < len(chrom_maxes):
                left_bound = chrom_maxes[left_idx] + 1
                right_bound = chrom_maxes[right_idx] - 1
                while (left_bound + 1) < right_bound:
                    mid_dist = (right_bound - left_bound) / 2.0
                    mid_element_idx = left_bound + int(np.floor(mid_dist))
                    mid_element_int = smoothed_ints_vec[mid_element_idx]

                    if mid_element_int <= smoothed_ints_vec[mid_element_idx + 1]:
                        right_bound = mid_element_idx
                    else:
                        left_bound = mid_element_idx

                min_rt = left_bound if smoothed_ints_vec[left_bound] < smoothed_ints_vec[right_bound] else right_bound
                min_int = smoothed_ints_vec[min_rt]

                left_max_int = smoothed_ints_vec[chrom_maxes[left_idx]]
                right_max_int = smoothed_ints_vec[chrom_maxes[right_idx]]

                left_rt = rt_values[chrom_maxes[left_idx]]
                mid_rt = rt_values[min_rt]
                right_rt = rt_values[chrom_maxes[right_idx]]

                left_dist = abs(mid_rt - left_rt)
                right_dist = abs(right_rt - mid_rt)
                min_dist = self.min_fwhm / 2.0

                if (left_max_int / min_int >= 2.0 and
                    right_max_int / min_int >= 2.0 and
                    left_dist >= min_dist and
                    right_dist >= min_dist):
                    chrom_mins.append(min_rt)
                    left_idx = right_idx
                    right_idx += 1
                else:
                    if left_max_int > right_max_int:
                        right_idx += 1
                    else:
                        left_idx = right_idx
                        right_idx += 1

        return chrom_maxes, chrom_mins

    def detect_peaks(self, mt):
        return self.detect_elution_peaks(mt)

    def detect_peaks_parallel(self, mt_vec):
        with Pool() as pool:
            return pool.map(self.detect_elution_peaks, mt_vec)

    def detect_elution_peaks(self, mt):
        scan_time = np.mean(np.diff(mt['rt']))
        win_size = int(np.ceil(self.chrom_fwhm / scan_time))

        # Step 1: Smooth data
        self.smooth_data(mt, win_size)

        # Step 2: Identify local maxima and minima
        maxes, mins = self.find_local_extrema(mt, win_size // 2)

        # Step 3: Split mass trace according to detected peaks
        if len(maxes) == 1:
            pw_ok = True
            snr_ok = True

            if self.width_filtering == "fixed":
                act_fwhm = self.estimate_fwhm(mt)
                if act_fwhm < self.min_fwhm or act_fwhm > self.max_fwhm:
                    pw_ok = False

            if self.masstrace_snr_filtering:
                if self.compute_apex_snr(mt) < self.chrom_peak_snr:
                    snr_ok = False

            if pw_ok and snr_ok:
                mt['smoothed_max_rt'] = mt['rt'].iloc[np.argmax(mt['smoothed_intensity'])]
                if self.width_filtering != "fixed":
                    self.estimate_fwhm(mt)
                return [mt]
        elif not maxes:
            return []
        else:
            sub_traces = []
            last_idx = 0
            mins.append(len(mt) - 1)

            for min_idx in mins:
                sub_trace = mt.iloc[last_idx:min_idx + 1].copy()
                last_idx = min_idx + 1

                pw_ok = True
                snr_ok = True

                if self.width_filtering == "fixed":
                    act_fwhm = self.estimate_fwhm(sub_trace)
                    if act_fwhm < self.min_fwhm or act_fwhm > self.max_fwhm:
                        pw_ok = False

                if self.masstrace_snr_filtering:
                    if self.compute_apex_snr(sub_trace) < self.chrom_peak_snr:
                        snr_ok = False

                if pw_ok and snr_ok:
                    sub_trace['smoothed_max_rt'] = sub_trace['rt'].iloc[np.argmax(sub_trace['smoothed_intensity'])]
                    sub_trace['label'] = f"{mt['label'].iloc[0]}.{min_idx + 1}"
                    if self.width_filtering != "fixed":
                        self.estimate_fwhm(sub_trace)
                    sub_traces.append(sub_trace)

            return sub_traces

    def smooth_data(self, mt, win_size):
        mt['smoothed_intensity'] = savgol_filter(mt['intensity'], window_length=win_size, polyorder=2)

    def estimate_fwhm(self, mt):
        # Estimate FWHM
        max_idx = np.argmax(mt['smoothed_intensity'])
        max_int = mt['smoothed_intensity'].iloc[max_idx]
        half_max_int = max_int / 2.0

        left_idx = max_idx
        right_idx = max_idx

        while left_idx > 0 and mt['smoothed_intensity'].iloc[left_idx] > half_max_int:
            left_idx -= 1

        while right_idx < len(mt) - 1 and mt['smoothed_intensity'].iloc[right_idx] > half_max_int:
            right_idx += 1

        fwhm = mt['rt'].iloc[right_idx] - mt['rt'].iloc[left_idx]

        return fwhm
    

if __name__ == "__main__":

    feature_matrix_file = "rt15s/191017USXP001_PN.feature_matrix.csv"
    feature_matrix_df = pd.read_csv(feature_matrix_file, float_precision="high")

    feature_id = 829491387311297880

    rt = feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,2] 
    mz = feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,3]

    rts = [ float(i) for i in feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,14].split(",") ]
    intys = [ float(i) for i in feature_matrix_df[feature_matrix_df["feature_id"] == feature_id].iloc[0,15].split(",") ]

    data = {
        'rt': rts,
        'intensity': intys,
        'smoothed_intensity': intys,
        'label': ['trace1'] * len(rts)
    }

    mt = pd.DataFrame(data)

    epd = ElutionPeakDetection()
    detected_peaks = epd.detect_peaks(mt)

    if len(detected_peaks) == 0:
        print("No peaks detected.")
        exit()
    elif len(detected_peaks) == 1:
        print("One peak detected.")
        start_rt = detected_peaks[0]['rt'].iloc[0]
        end_rt = detected_peaks[0]['rt'].iloc[-1]
        apex_rt = detected_peaks[0]['smoothed_max_rt'].iloc[0]

        for_entropy_calc = np.column_stack((detected_peaks[0]['rt'], detected_peaks[0]['smoothed_intensity']))
        max_tr, entropy_score = entropy_calculator(for_entropy_calc)

        plt.figure(figsize=(12, 6))
        plt.plot(mt['rt'], mt['intensity'], label='Original')
        plt.plot(mt['rt'], mt['smoothed_intensity'], label='Smoothed')
        plt.axvline(x=apex_rt, color='r', linestyle='--', label='Peak apex')
        plt.axvline(x=start_rt, color='g', linestyle='--', label='Peak start')
        plt.axvline(x=end_rt, color='g', linestyle='--', label='Peak end')
        plt.xlabel('Retention Time')
        plt.ylabel('Intensity')
        plt.title(f'peak_id: {feature_id}\nRT: {rt:.2f}, mz: {mz:.6f}\nEntropy: {entropy_score:.2f}')
        plt.legend()
        plt.savefig(f"peak_{feature_id}.png")
    else:
        # 从所有检测到的峰中选择 apex rt 与 rt 最接近的峰
        min_diff = np.inf
        min_diff_idx = 0
        for i, peak in enumerate(detected_peaks):
            apex_rt = peak['smoothed_max_rt'].iloc[0]
            diff = abs(rt - apex_rt)
            if diff < min_diff:
                min_diff = diff
                min_diff_idx = i

        print(f"Multiple peaks detected. Selected peak {min_diff_idx + 1}.")

        start_rt = detected_peaks[min_diff_idx]['rt'].iloc[0]
        end_rt = detected_peaks[min_diff_idx]['rt'].iloc[-1]
        apex_rt = detected_peaks[min_diff_idx]['smoothed_max_rt'].iloc[0]

        for_entropy_calc = np.column_stack((detected_peaks[min_diff_idx]['rt'], detected_peaks[min_diff_idx]['smoothed_intensity']))
        max_tr, entropy_score = entropy_calculator(for_entropy_calc)

        plt.figure(figsize=(12, 6))
        plt.plot(mt['rt'], mt['intensity'], label='Original')
        plt.plot(mt['rt'], mt['smoothed_intensity'], label='Smoothed')
        plt.axvline(x=apex_rt, color='r', linestyle='--', label='Peak apex')
        plt.axvline(x=start_rt, color='g', linestyle='--', label='Peak start')
        plt.axvline(x=end_rt, color='g', linestyle='--', label='Peak end')
        plt.xlabel('Retention Time')
        plt.ylabel('Intensity')
        plt.title(f'peak_id: {feature_id}\nRT: {rt:.2f}, mz: {mz:.6f}\nEntropy: {entropy_score:.2f}')
        plt.legend()
        plt.savefig(f"peak_{feature_id}.png")
