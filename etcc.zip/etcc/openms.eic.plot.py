import os
import sys
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from multiprocessing import Pool, cpu_count

# ... (keep all the existing functions)

def eic_plot(feature_data):
    feature_id, RT, mz, eic_rts, eic_intys, output_fig_file = feature_data
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot(eic_rts, eic_intys, color="blue")
    ax.scatter(eic_rts, eic_intys, s=5, color="red")
    ax.axvline(x=RT, linestyle='--', color='green', label=f'RT={RT}')
    ax.set_xlabel("RT (seconds)")
    ax.set_ylabel("Intensity")
    ax.set_title(f"Peak_id: {feature_id}\nRT: {RT:.2f}, mz: {mz:.6f}")
    ax.legend()
    fig.savefig(output_fig_file, bbox_inches='tight')
    plt.close(fig)

def generate_feature_eic_plot_parallel(featureXML_df, output_dir, num_processes=None):
    if num_processes is None:
        num_processes = cpu_count()

    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    feature_data_list = []
    for _, row in featureXML_df.iterrows():
        feature_id = row["feature_id"]
        RT = row["RT"]
        mz = row["mz"]
        eic_rts = np.fromstring(row["chrom_RT"], sep=',')
        eic_intys = np.fromstring(row["chrom_intensity"], sep=',')
        output_fig_file = os.path.join(output_dir, f"{feature_id}.png")
        feature_data_list.append((feature_id, RT, mz, eic_rts, eic_intys, output_fig_file))

    with Pool(processes=num_processes) as pool:
        pool.map(eic_plot, feature_data_list)

if __name__ == "__main__":
    feature_matrix_file = sys.argv[1]
    output_dir = sys.argv[2]

    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    feature_matrix_df = pd.read_csv(feature_matrix_file, float_precision="high")
    
    generate_feature_eic_plot_parallel(feature_matrix_df, output_dir, 6)