#!/bin/bash
set -e

cat sample.all.txt | while read sample_name
do
	ion_mode=$(echo "${sample_name}" | cut -d '_' -f 3 | awk -F '' '{print $1""$2""$3}')
	mzML_file="/d/Project/MetSoc2022_CASMI/mzML/${ion_mode}/${sample_name}.mzML"
	output_dir="/d/Project/MetSoc2022_CASMI/results2/${ion_mode}/${sample_name}"
	
	if [ ! -d ${output_dir}/summaries ]
	then
		mkdir -p ${output_dir}/summaries
	fi

	set -x
	sirius login --email=syu93@wisc.edu --password=Password111!
	sirius --no-citations --input ${mzML_file} --project ${output_dir}/${sample_name}.sirius formulas -p orbitrap zodiac fingerprints classes structures denovo-structures >${output_dir}/${sample_name}.run.log 2>&1
	sirius --no-citations --project ${output_dir}/${sample_name}.sirius write-summaries --format=TSV --full-summary --output=${output_dir}/summaries --quote-strings >${output_dir}/${sample_name}.write-summaries.log 2>&1
	set +x
	sleep 1
done
