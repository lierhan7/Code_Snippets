#!/bin/bash
set -e

ls */*/*run.log | while read line
do
	fail_count=$(cat ${line} | grep "Failed" | wc -l)
	if [ ${fail_count} -eq 0 ]
	then
		echo -e "${line}\tsuccess"
	else
		echo -e "${line}\tfail"
	fi
done
