
import glob
import pandas as pd
import numpy as np


def merge_ms_data(df1, df2, RT_tolerance, mz_tolerance_ppm, formula_match):
    """
    按照RT和mz的容差值合并两个质谱数据框
    
    参数:
    df1: 参考数据框，包含RT和mz列
    df2: 待匹配数据框，包含RT和mz列
    RT_tolerance: RT容差值（分钟）
    mz_tolerance_ppm: mz容差值（ppm）
    
    返回:
    merged_df: 合并后的数据框
    """
    # 创建结果存储列表
    matches = []
    
    # 遍历df1中的每一行
    for idx1, row1 in df1.iterrows():
        # 计算当前RT范围
        rt_min = row1['RT [min]'] - RT_tolerance
        rt_max = row1['RT [min]'] + RT_tolerance
        
        # 计算当前mz的容差范围（ppm）
        mz_tolerance = row1['Precursor m/z (Da)'] * mz_tolerance_ppm / 1e6
        mz_min = row1['Precursor m/z (Da)'] - mz_tolerance
        mz_max = row1['Precursor m/z (Da)'] + mz_tolerance
        
        # 在df2中筛选符合条件的行
        if formula_match:
            matches_df2 = df2[
                (df2['retentionTimeInMinutes'].between(rt_min, rt_max)) &
                (df2['ionMass'].between(mz_min, mz_max)) & 
                (df2['molecularFormula'] == row1['Formula'])
            ]
        else:
            matches_df2 = df2[
                (df2['retentionTimeInMinutes'].between(rt_min, rt_max)) &
                (df2['ionMass'].between(mz_min, mz_max))
            ]
            
        # 如果找到匹配项
        if not matches_df2.empty:
            # 遍历匹配项
            for idx2, row2 in matches_df2.iterrows():
                matches.append({
                    **{col: row1[col] for col in df1.columns},
                    **{col: row2[col] for col in df2.columns}
                })
        else:
            matches.append({
                **{col: row1[col] for col in df1.columns},
                **{col: np.nan for col in df2.columns}
            })
        
    # 创建结果数据框
    merged_df = pd.DataFrame(matches)
    
    return merged_df


def main():

    mz_tolerance_ppm = 10    # ppm
    rt_tolerance = 0.2  # minutes

    reference_file = 'MetSoc2022_CASMI_Workshop_Challenges_KEY_ALL_FINAL.select.xlsx'
    reference_df = pd.read_excel(reference_file)

    sample_list = reference_df['File'].unique().tolist()

    formula_match_list = []
    structure_match_list = []
    formula_match_exact_list = []
    structure_match_exact_list = []
    for sample in sample_list:
        print(f'Processing {sample}...')
        sample_reference_df = reference_df[reference_df['File'] == sample].copy()

        ion_mode = sample.split('_')[2][:3]

        sample_formula_results_file = f'{ion_mode}\{sample}\summaries\\formula_identifications_all.tsv'
        sample_formula_df = pd.read_csv(sample_formula_results_file, sep='\t')
        sample_formula_df_filtered = merge_ms_data(sample_reference_df, sample_formula_df, rt_tolerance, mz_tolerance_ppm, False)
        formula_match_list.append(sample_formula_df_filtered)
        sample_formula_df_filtered_exact = merge_ms_data(sample_reference_df, sample_formula_df, rt_tolerance, mz_tolerance_ppm, True)
        formula_match_exact_list.append(sample_formula_df_filtered_exact)
        
        sample_structure_results_file = f'{ion_mode}\{sample}\summaries\structure_identifications_all.tsv'
        sample_structure_df = pd.read_csv(sample_structure_results_file, sep='\t')
        sample_structure_df_filtered = merge_ms_data(sample_reference_df, sample_structure_df, rt_tolerance, mz_tolerance_ppm, False)
        structure_match_list.append(sample_structure_df_filtered)
        sample_structure_df_filtered_exact = merge_ms_data(sample_reference_df, sample_structure_df, rt_tolerance, mz_tolerance_ppm, True)
        structure_match_exact_list.append(sample_structure_df_filtered_exact)

    formula_match_df = pd.concat(formula_match_list)
    formula_match_df.to_excel('formula_match_results.xlsx', index=False)

    formula_match_exact_df = pd.concat(formula_match_exact_list)
    formula_match_exact_df.to_excel('formula_match_results.exact.xlsx', index=False)

    structure_match_df = pd.concat(structure_match_list)
    structure_match_df.to_excel('structure_match_results.xlsx', index=False)

    structure_match_df = pd.concat(structure_match_exact_list)
    structure_match_df.to_excel('structure_match_results.exact.xlsx', index=False)


if __name__ == '__main__':
    main()